package com.zybooks.projecttwoweighttrackerapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

//This class allows a user to add a weight to their personal database. By clicking the add button,
//the app accesses the weight db. If the date provided does not already have a weight recorded
//for it, then the date and the corresponding weight entered by the user will be added to the database

public class AddWeightActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight);

        WeightDatabase db = new WeightDatabase(getApplicationContext());

        Button addItem = findViewById(R.id.AddButton);
        EditText textViewDate = findViewById(R.id.editTextDate);
        EditText textViewWeight = findViewById(R.id.editTextWeight);

        String user = getIntent().getStringExtra("user");

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = textViewDate.getText().toString();
                String weight = textViewWeight.getText().toString();
                if (date.isEmpty() || weight.isEmpty()) {
                    Toast.makeText(AddWeightActivity.this, "Please enter the date and weight.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!db.checkDate(date)) {
                    db.addItem(date, weight);
                    Intent intent = new Intent(AddWeightActivity.this, WeightActivity.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddWeightActivity.this, " Your weight for this day has already been recorded.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
