package com.zybooks.projecttwoweighttrackerapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;


//This class allows a user to add and delete weights recorded for a date. The information entered
//is displayed on the user interface as a list. If the user has granted permission for the app to
//send SMS notifications, then the app will send this once the user has reached their goal weight.
//The user is able to add new or delete existing records in the app using the add and delete methods

public class WeightActivity extends AppCompatActivity  {

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;
    ArrayList<String> date, weight;
    WeightDatabase db;
    private ArrayAdapter<String> adapter;
    private ListView listView;
    String user;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        ListView bodyListView = findViewById(R.id.bodyListView);
        db = new WeightDatabase(this);
        date = new ArrayList<>();
        weight = new ArrayList<>();
        listView = findViewById(R.id.bodyListView);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, date);
        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        displayData();



        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, date);
        bodyListView.setAdapter(adapter);

        user = getIntent().getStringExtra("user");
        ImageButton add = findViewById(R.id.addItemButton);
        ImageButton delete = findViewById(R.id.deleteButton);
        displayData();


        if (!checkPermission(android.Manifest.permission.SEND_SMS)) {
            ActivityCompat.requestPermissions(this, new String[] {android.Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WeightActivity.this, AddWeightActivity.class);
                intent.putExtra("user", user);
                startActivityForResult(intent, 1);

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int item = listView.getCheckedItemPosition();
                if (item != ListView.INVALID_POSITION) {
                    String selectedDate = date.get(item);
                    db.deleteItem(selectedDate);
                    date.remove(item);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(WeightActivity.this, "Weight has been deleted.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(WeightActivity.this, "Please select the weight you'd like to delete.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    public Boolean checkPermission(String permission) {
        int checkPermission = ContextCompat.checkSelfPermission(this, permission);
        return (checkPermission == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayData(); 
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SEND_SMS_PERMISSION_REQUEST_CODE) {

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
            }

            else {
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }




    public void sendSMS(String phoneNumber, String weight) {


        if (checkPermission(android.Manifest.permission.SEND_SMS)) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, "Your goal weight of " + weight + "lbs. has been reached! Congratulations!", null, null);
        }
    }



    private void displayData() {
        Cursor cursor = db.getItems();
        if (cursor.getCount() == 0) {
            Toast.makeText(WeightActivity.this, "No Records Exist Yet. Record a Weight Now.", Toast.LENGTH_SHORT).show();

        }
        else {
            date.clear();
            weight.clear();
            while (cursor.moveToNext()) {
                date.add(cursor.getString(1));
                weight.add(cursor.getString(2));
            }
            adapter.notifyDataSetChanged();
        }
    }
}
