package com.zybooks.projecttwoweighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import androidx.appcompat.app.AppCompatActivity;

//This class allows the user to register themselves to create an account. As long as the username,
//password, and phone number are valid, the information entered for each of these variables is
//added to the login database and their information will be saved for the next time they try to '
//sign in

public class CreateAccountActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newuser);

        WeightDatabase weightDatabase = new WeightDatabase(getApplicationContext());

        Button create = findViewById(R.id.RegisterButton);
        EditText editNewUsername = findViewById(R.id.editUsername);
        EditText editNewPassword = findViewById(R.id.editPassword);
        EditText editNewNumber = findViewById(R.id.editPhoneNumber);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editNewUsername.getText().toString();
                String password = editNewPassword.getText().toString();
                String number = editNewNumber.getText().toString();

                if (username.isEmpty() || password.isEmpty() || number.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter a username, password, and number.", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    weightDatabase.addUser(username, password, number);
                    Toast.makeText(CreateAccountActivity.this, "Account was created successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CreateAccountActivity.this, MainActivity.class);
                    CreateAccountActivity.this.startActivity(intent);
                    finish();
                }
                catch (Exception e) {
                    Toast.makeText(CreateAccountActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

