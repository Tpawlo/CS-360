package com.zybooks.projecttwoweighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;




//This is the main activity class. This is used to allow the user to enter their username
//and password and log into their account. If the username or password entered is invalid
//or not already in the database, then the user is given an error message. If the username
//and password match an entry that is given in the database, then they are successfully
//logged in and can access their account. In this activity, it also allows a user to
//create an account if they are not already registered, as well as check their permission
//to see if the app can send SMS notifications

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        WeightDatabase weightDatabase = new WeightDatabase(getApplicationContext());


        Button login = findViewById(R.id.SignInButton);
        Button create = findViewById(R.id.RegisterButton);
        EditText editUsername = findViewById(R.id.UsernameText);
        EditText editPassword = findViewById(R.id.PasswordText);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editUsername.getText().toString();
                String password = editPassword.getText().toString();

                if (!username.isEmpty() && !password.isEmpty()) {
                    boolean isUser = weightDatabase.checkLogin(username, password);
                    if (isUser) {
                        Intent intent = new Intent(MainActivity.this, WeightActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "User has not yet been registered", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter your username and password", Toast.LENGTH_SHORT).show();
                }
            }
        });


        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });
    }

}

