package com.zybooks.projecttwoweighttrackerapp;


import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


//This class creates the weight database that will hold all the app's information, including
//the user's recorded weights, as well as the username, password, and phone number information
//for the user. In the database, there is a table for the login information, and a table for the
//recorded weights information. There are methods to add a user, add a weight, delete a weight,
//check that the user is in the database, as well as check that the phone number matches the account

public class WeightDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight.db";
    Context context;

    WeightDatabase(Context context) {
        super(context, "weight.db", null, 1);
        this.context = context;
    }

    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_NUMBER = "number";
    }

    private static final class WeightTable {
        private static final String TABLE = "weight";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + "integer primary key autoincrement," +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text," +
                LoginTable.COL_NUMBER + " text)");

        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement," +
                WeightTable.COL_DATE + " text, " +
                WeightTable.COL_WEIGHT + " real)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }



    public void addUser(String username, String password, String number) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues tableValues = new ContentValues();
        tableValues.put(LoginTable.COL_USERNAME, username);
        tableValues.put(LoginTable.COL_PASSWORD, password);
        tableValues.put(LoginTable.COL_NUMBER, number);


        db.insert(LoginTable.TABLE, null, tableValues);
    }

    public Boolean checkLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + LoginTable.TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username, password});


        return cursor.moveToFirst();
    }




    public void addItem(String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues tableValues = new ContentValues();
        tableValues.put(WeightTable.COL_DATE, date);
        tableValues.put(WeightTable.COL_WEIGHT, weight);


        db.insert(WeightTable.TABLE, null, tableValues);
    }




    public void deleteItem (String date) {
        SQLiteDatabase db = getWritableDatabase();

        String whereClause = WeightTable.COL_DATE + " = ?";
        String [] whereArgs = new String[] {date};

        db.delete(WeightTable.TABLE, whereClause, whereArgs);
    }



    public Boolean checkDate(String itemDate) {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + WeightTable.TABLE + " where date = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {itemDate});


        return cursor.moveToFirst();
    }


    public Cursor getItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("Select * from " + WeightTable.TABLE, null);
    }
}
