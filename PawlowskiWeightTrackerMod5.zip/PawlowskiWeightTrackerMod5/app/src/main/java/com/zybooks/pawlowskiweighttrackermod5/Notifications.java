package com.zybooks.pawlowskiweighttrackermod5;

import android.content.Context;
import android.content.SharedPreferences;

public class Notifications {
    private static SharedPreferences sharedPref;
    private static SharedPreferences.Editor editor;
    private String username;

    public void saveNotificationPreferences(boolean isEnabled) {
        editor.putBoolean(username, isEnabled);
        editor.apply();
    }

    public boolean getNotificationPreference() {
        return sharedPref.getBoolean(username, false);
    }

}
